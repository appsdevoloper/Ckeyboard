//
//  ViewController.swift
//  CustomKeyboard
//
//  Created by Apple on 22/10/19.
//  Copyright © 2019 appzoo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func createAction(_ sender: Any) {
        let customVC = self.storyboard?.instantiateViewController(withIdentifier: "customboardview") as! CustomboardViewController
        customVC.modalPresentationStyle = .overFullScreen
        customVC.modalTransitionStyle = .crossDissolve
        self.present(customVC, animated: true, completion: nil)
    }
}

