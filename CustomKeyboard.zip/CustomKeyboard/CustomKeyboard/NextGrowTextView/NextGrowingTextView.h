//
//  NextGrowingTextView.h
//
//  Created by Apple on 29/07/19.
//  Copyright © 2019 demo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NextGrowingTextView.
FOUNDATION_EXPORT double NextGrowingTextViewVersionNumber;

//! Project version string for NextGrowingTextView.
FOUNDATION_EXPORT const unsigned char NextGrowingTextViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NextGrowingTextView/PublicHeader.h>


