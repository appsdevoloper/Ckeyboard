//
//  CustomboardViewController.swift
//  CustomKeyboard
//
//  Created by Apple on 22/10/19.
//  Copyright © 2019 appzoo. All rights reserved.
//

import UIKit

class CustomboardViewController: UIViewController, UITextViewDelegate {

    @IBOutlet weak var toolbarView: UIView!
    @IBOutlet weak var inputContainerView: UIView!
    @IBOutlet weak var inputContainerViewBottom: NSLayoutConstraint!
    @IBOutlet weak var growingTextView: NextGrowingTextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(CustomboardViewController.keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(CustomboardViewController.keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        self.growingTextView.layer.cornerRadius = 4
        self.growingTextView.backgroundColor = UIColor.clear
        /*self.growingTextView.placeholderAttributedText = NSAttributedString(
            string: "Placeholder text",
            attributes: [
                .font: self.growingTextView.textView.font!,
                .foregroundColor: UIColor.gray
            ]
        )*/
        
        // MARK: TapGesture For Self View
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        self.view.addGestureRecognizer(tap)
        
        // MARK: View Background
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.7)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.growingTextView.resignFirstResponder()
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func keyboardWillHide(_ sender: Notification) {
        if let userInfo = (sender as NSNotification).userInfo {
            if let _ = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.size.height {
                self.inputContainerViewBottom.constant =  0
                UIView.animate(withDuration: 0.25, animations: { () -> Void in self.view.layoutIfNeeded() })
            }
        }
    }
    
    @objc func keyboardWillShow(_ sender: Notification) {
        if let userInfo = (sender as NSNotification).userInfo {
            if ((userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.size.height) != nil {
                self.inputContainerViewBottom.constant = -1000
                //self.inputContainerViewBottom.constant = keyboardHeight
                UIView.animate(withDuration: 0.25, animations: { () -> Void in
                    self.view.layoutIfNeeded()
                })
            }
        }
    }
    
    override func viewWillLayoutSubviews() {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.toolbarView.roundCorners([.topLeft, .topRight], radius: 12)
    }
}

extension UIView {
    func roundCorners(_ corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}
